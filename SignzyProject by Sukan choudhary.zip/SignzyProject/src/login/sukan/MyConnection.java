package login.sukan;

public interface MyConnection {
	String username="sa";
	String pwd="sukan";
	String connUrl="jdbc:h2:~/test";

}
