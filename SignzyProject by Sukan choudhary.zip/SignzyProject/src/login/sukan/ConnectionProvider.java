package login.sukan;

import java.sql.Connection;
import java.sql.DriverManager;


public class ConnectionProvider implements MyConnection {
	
	static Connection con=null;
	
	public static Connection getCon()
	{
	try{
		Class.forName("org.h2.Driver");
		con=DriverManager.getConnection(connUrl,username,pwd);
		
	}catch(Exception e)
	{
		System.out.println(e);
	}
	return con;

}}
